<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{imageresize}prestashop>imageresize_8b0e1f3f6e8d2e7f8c0e1f3f6e8d2e7f'] = 'Image Resize';
$_MODULE['<{imageresize}prestashop>imageresize_9b0e1f3f6e8d2e7f8c0e1f3f6e8d2e7f'] = 'Redimensionne automatiquement les images selon les paramètres du thème actif';
$_MODULE['<{imageresize}prestashop>imageresize_1b0e1f3f6e8d2e7f8c0e1f3f6e8d2e7f'] = 'Êtes-vous sûr de vouloir désinstaller ce module ?';
